#!perl -w

use strict;

my $input = shift(@ARGV) or die; #AG_Nuclei_R2_metagenome_aligned.sam
my $num = shift(@ARGV) or die; #how many to look for
my $output = shift(@ARGV) or die;
unlink(qq{$output});

my $found = 0;
my $total = 0;
open(B, ">>$output");
open(A, "<$input");
LOOP:while(my $line = <A>){
    chomp $line;
    if($line !~ m/^\@/){
	#print $line, "\n";
	my @a = split(/\t/, $line);
	my $str = substr($a[9], 0, 16);
	$total++;
	if(($total % 1000000) == 0){
	    print $total, "\n";
	}
	if($a[2] =~ m/mel/){
	    print B $a[0], "\t", $a[2], "\n";
	    $found++;
	    if($found < $num){
		next LOOP;
	    }else{
		last LOOP;
	    }
	}elsif($a[2] =~ m/sim/){
	    print B $a[0], "\t", $a[2], "\n";
	    $found++;
	    if($found < $num){
		next LOOP;
	    }else{
		last LOOP;
	    }
	}elsif($a[2] =~ m/yak/){
	    print B $a[0], "\t", $a[2], "\n";		    
	    $found++;
	    if($found < $num){
		next LOOP;
	    }else{
		last LOOP;
	    }
	}	 
    } 
}

close A;
close B;
