#!perl -w

use strict;

my $input = shift(@ARGV) or die;#AG_Nuclei_S60_L007_R1_001.fastq.gz
my $codes = shift(@ARGV) or die; #Barcodes_subset
my $sam = shift(@ARGV) or die; #Best_match_reads_per_genome_*
my $output = shift(@ARGV) or die;
unlink(qq{$output});

my %code = ();
open(X, "<$codes");
while(my $line = <X>){
    chomp $line;
    my @x = split(/\t/, $line);
    if($x[1] >= 5000){
        $code{$x[0]} = $x[1];
    }
}
close X;

my %ids = ();
my %out = (); #toss these ones out
my $extra = 0;
open(B, "<$sam");
while(my $line2 = <B>){
    chomp $line2;
    my @b = split(/\t/, $line2);
    if(!(exists($ids{$b[0]}))){
	$ids{$b[0]} = $b[1];
    }elsif(exists($ids{$b[0]})){
	$out{$b[0]} = 1;
	$extra++;
    }
}
close B;
print "Extra \t", $extra, "\n";

my $total = 0;
my $count = 0;
my $current = 0;
my $true = 0;
my $found = 0;

my %barumi = ();
my %umi = ();

open(A, "gunzip -c $input | ");
open(B, ">>$output");
LOOP:while(my $line = <A>){
    chomp $line;
    if($count == 0){ #evaluate ID and pick ones that have unique species info
	$line =~ s/^\@//;
	my @y = split(/\s+/, $line);
	$current = $y[0];
	if(exists($ids{$y[0]}) and !(exists($out{$y[0]}))){#some are best matches to multiple species - don't use
	    $true = 1; #one to evaluate - some will belong to barcodes that I won't keep
	    #print $y[0], "\t", "keep", "\n";
	    $found++;
#	    print "Found\n";
	}else{
	    $true = 0; #not one I use
	    #print $y[0], "\t", "pitch", "\n";
	}
        $count++;
        next LOOP;
    }elsif($count == 1){
        
        my $str = substr($line, 0, 16);
	my $str2 = substr($line, 16, 10);
	
        #print $str, "\t", $str2, "\n";R
	if($true == 1){ #this is one to use 
	    if(exists($code{$str})){ #barcode is good
		if(!(exists($barumi{$str . "\t" . $str2}))){
		    $barumi{$str . "\t" . $str2} = 1;
		    if(!(exists($umi{$str}))){
			$umi{$str} = 1;
		    }elsif(exists($umi{$str})){
			$umi{$str}++;
		    }
		}
		print B $str, "\t", $ids{$current}, "\t", $current, "\t", $code{$str}, "\t", $umi{$str}, "\n";				
	    }
	}elsif($true == 0){
	    #	print $current, "\n";	
	}
	$total++;
	if(($total % 1000000) == 0){
	    print $total, "\n";
	}
	if($total >= 10000000){
	    print $total, "\n";
	    $true = 0;
	    last LOOP;
	}
	$true = 0;
	$count++;
	next LOOP;
    }elsif($count == 2){
        $count++;
        next LOOP;
    }elsif($count == 3){
        $count = 0;
        next LOOP;
    }
}
close A;
close B;

print "Found \t", $found, "\n";
