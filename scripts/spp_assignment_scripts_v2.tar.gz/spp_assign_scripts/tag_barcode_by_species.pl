#!perl -w

use strict;

my $input = shift(@ARGV) or die; #Best_match_to_barcodes
my $cut = shift(@ARGV) or die; #what cutoff 0.5, 0.7???
my $output = shift(@ARGV) or die; #Barcode_by_species_*
unlink(qq{$output});

my %mel = ();
my %sim = ();
my %yak = ();
my %total = ();
my %umi = ();
my %sum = ();

open(A, "<$input");
while(my $line = <A>){
    chomp $line;
    my @a = split(/\t/, $line);
    $total{$a[0]} = $a[3];
    $umi{$a[0]} = $a[4];
    if(!(exists($mel{$a[0]}))){
	$mel{$a[0]} = 0;
	$sim{$a[0]} = 0;
	$yak{$a[0]} = 0;
	$sum{$a[0]} = 0;
    }
    
    if($a[1] =~ m/mel/){
	$mel{$a[0]}++;
	$sum{$a[0]}++;
    }elsif($a[1] =~ m/sim/){
	$sim{$a[0]}++;
	$sum{$a[0]}++;
    }elsif($a[1] =~ m/yak/){
	$yak{$a[0]}++;
	$sum{$a[0]}++;
    }
}
close A;

open(B, ">>$output");
print B "Barcode\tSpecies\tMel\tSim\tYak\tSum\tBtotal\tUMI\n";
while((my $k, my $v) = each(%mel)){
 #   if($total{$k} >= 10000){
	my $sum = $v + $sim{$k} + $yak{$k};
	
	if(($v / $sum) > $cut){	
	    print B $k, "\t", "mel", "\t", $v, "\t", $sim{$k}, "\t", $yak{$k}, "\t", $sum{$k}, "\t", $total{$k}, "\t", $umi{$k}, "\n";
	}elsif(($sim{$k} / $sum) > $cut){
	    print B $k, "\t", "sim", "\t", $v, "\t", $sim{$k}, "\t", $yak{$k}, "\t", $sum{$k}, "\t", $total{$k}, "\t", $umi{$k}, "\n";
	}elsif(($yak{$k} / $sum) > $cut){
	    print B $k, "\t", "yak", "\t", $v, "\t", $sim{$k}, "\t", $yak{$k}, "\t", $sum{$k}, "\t", $total{$k}, "\t", $umi{$k}, "\n";
	}else{
	    print B $k, "\t", "N", "\t", $v, "\t", $sim{$k}, "\t", $yak{$k}, "\t", $sum{$k}, "\t", $total{$k}, "\t", $umi{$k}, "\n";
	}
 #   }
}
close B;
